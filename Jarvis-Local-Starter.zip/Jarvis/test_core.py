"""Run with: python -m unittest test_core -v. Uses a temporary database."""
import os, tempfile, unittest, json, threading, urllib.request, urllib.error
_temp = tempfile.TemporaryDirectory()
os.environ['JARVIS_DATA_DIR'] = _temp.name
import server
class CoreTests(unittest.TestCase):
    def setUp(self):
        with server.conn() as c:
            c.execute('DELETE FROM records'); c.execute('DELETE FROM audit')
    def add(self,k,b):
        with server.conn() as c: return server.create(c,k,b)
    def test_decimal_and_transfer(self):
        a=self.add('account',{'title':'Bank A','opening':'1000.10','date':'2026-01-01'})
        b=self.add('account',{'title':'Wallet','opening':'0','date':'2026-01-01'})
        self.add('transaction',{'account':a,'to':b,'direction':'transfer','amount':'200.05','date':'2026-01-03'})
        with server.conn() as c: rows=server.records(c,'transaction')
        self.assertEqual(rows[0]['cents'],20005)
        self.assertEqual(100010-rows[0]['cents']+rows[0]['cents'],100010)
        for bad in ('NaN','Infinity','-1','0','1.001'):
            with self.assertRaises(ValueError):server.amount(bad,True)
    def test_debt_repayments(self):
        d=self.add('debt',{'title':'Borrower','amount':'100','date':'2026-01-01','direction':'lent'})
        self.add('repayment',{'debt':d,'amount':'30.25','date':'2026-01-02'})
        with self.assertRaises(ValueError): self.add('repayment',{'debt':d,'amount':'70','date':'2026-01-02'})
        self.add('repayment',{'debt':d,'amount':'69.75','date':'2026-01-03'})
    def test_duplicate_and_opening_dates(self):
        a=self.add('account',{'title':'Bank','opening':'0','date':'2026-01-05'})
        t={'account':a,'direction':'in','amount':'100','date':'2026-01-05','import_key':'abc'}
        self.add('transaction',t)
        with self.assertRaises(ValueError):self.add('transaction',t)
        with self.assertRaises(ValueError):self.add('transaction',{**t,'date':'2026-01-04','import_key':'def'})
    def test_atomic_import(self):
        a=self.add('account',{'title':'Bank','opening':'0','date':'2026-01-01'})
        try:
            with server.conn() as c:
                server.create(c,'transaction',{'account':a,'direction':'in','amount':'100','date':'2026-01-02'})
                server.create(c,'transaction',{'account':a,'direction':'in','amount':'-1','date':'2026-01-02'})
        except ValueError:pass
        with server.conn() as c:self.assertEqual(server.records(c,'transaction'),[])
    def test_http_auth_and_origin(self):
        srv=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        t=threading.Thread(target=srv.serve_forever,daemon=True);t.start()
        origin='http://127.0.0.1:'+str(srv.server_port)
        try:
            with self.assertRaises(urllib.error.HTTPError) as err: urllib.request.urlopen(origin+'/api/state')
            self.assertEqual(err.exception.code,401)
            req=urllib.request.Request(origin+'/api/login',data=json.dumps({'token':server.TOKEN}).encode(),headers={'Origin':origin,'Content-Type':'application/json'})
            with urllib.request.urlopen(req) as r:cookie=r.headers['Set-Cookie'].split(';')[0]
            req=urllib.request.Request(origin+'/api/state',headers={'Cookie':cookie})
            with urllib.request.urlopen(req) as r:self.assertIn('records',json.load(r))
            req=urllib.request.Request(origin+'/api/create',data=b'{}',headers={'Origin':'http://evil.invalid','Cookie':cookie})
            with self.assertRaises(urllib.error.HTTPError) as err:urllib.request.urlopen(req)
            self.assertEqual(err.exception.code,403)
        finally:srv.shutdown();srv.server_close()
if __name__=='__main__':unittest.main()
