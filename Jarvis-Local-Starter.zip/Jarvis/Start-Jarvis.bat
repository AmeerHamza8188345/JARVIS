@echo off
cd /d "%~dp0"
py -3 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3 is required. Install it from https://www.python.org/downloads/windows/
  echo Then run this file again. See README.md for setup instructions.
  pause
  exit /b 1
)
py -3 server.py
pause
