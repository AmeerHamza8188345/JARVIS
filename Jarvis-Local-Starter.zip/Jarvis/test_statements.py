import unittest
from statements import preview
HEADER='Transaction Date,Description,Currency,Debit,Credit,Running Balance\n'
ACCOUNT=[{'id':'a','opening_cents':100000,'date':'2026-01-01'}]
class StatementTests(unittest.TestCase):
 def check(self,rows,**kwargs):return preview({'account':'a','csv':HEADER+rows,**kwargs},ACCOUNT,[])
 def test_debit_credit_and_commas(self):
  r=self.check('2026-01-02,"Tea, packing",LKR,200,,800\n2026-01-03,Payment,LKR,,500,"1,300.00"')
  self.assertEqual(r['closing_cents'],130000)
  self.assertEqual(r['rows'][0]['direction'],'out')
 def test_newest_dayfirst(self):
  r=self.check('03/01/2026,Payment,LKR,0,500,1300\n02/01/2026,Tea,LKR,200,0,800',order='newest',date_format='dmy')
  self.assertEqual(r['rows'][0]['date'],'2026-01-02')
 def test_errors(self):
  for row in ['2026-01-02,X,USD,200,,800','2026-01-02,X,LKR,200,100,900','2026-01-02,X,LKR,200,,799','2026-02-30,X,LKR,200,,800','2026-01-02,X,LKR,0,0,1000']:
   with self.subTest(row=row),self.assertRaises(ValueError):self.check(row)
 def test_duplicate(self):
  request={'account':'a','csv':HEADER+'2026-01-02,X,LKR,200,,800'}
  r=preview(request,ACCOUNT,[])
  again=preview(request,ACCOUNT,[dict(r['rows'][0],cents=20000)])
  self.assertEqual(again['count'],0); self.assertEqual(again['skipped'],1)
 def test_continuation(self):
  old=[{'account':'a','direction':'out','cents':20000,'date':'2026-01-02'}]
  r=preview({'account':'a','csv':HEADER+'2026-01-03,X,LKR,,500,1300'},ACCOUNT,old)
  self.assertEqual(r['closing_cents'],130000)
 def test_overlap_appends_only_new(self):
  old=preview({'account':'a','csv':HEADER+'2026-01-02,X,LKR,200,,800'},ACCOUNT,[])['rows'][0]
  r=preview({'account':'a','csv':HEADER+'2026-01-02,X,LKR,200,,800\n2026-01-03,Y,LKR,,500,1300'},ACCOUNT,[dict(old,cents=20000)])
  self.assertEqual((r['count'],r['skipped'],r['closing_cents']),(1,1,130000))
 def test_bank_export_and_opening(self):
  text=HEADER.rstrip('\n')+',,,\n03/01/2026,Y,LKR,,500,1300,,,\n02/01/2026,X,LKR,200,,800,,,\n,,,,,, Page 1 of ,,1'
  r=preview({'account':'a','csv':text,'use_statement_opening':True},[dict(ACCOUNT[0],opening_cents=0)],[])
  self.assertEqual(r['opening_update']['opening_cents'],100000)
  self.assertEqual(r['count'],2)
if __name__=='__main__':unittest.main()
