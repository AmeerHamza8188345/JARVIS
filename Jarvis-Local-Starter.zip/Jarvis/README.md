# Jarvis — local starter v0.1

A working starting point for Ameer: daily planning, Azmar & Co, personal money tracking and aviation practice. This release runs on your Windows PC. It is not the finished autonomous assistant, and it has not been installed on your PC yet.

## Start on Windows

1. Extract the entire ZIP into a permanent folder, for example `Documents\Jarvis`.
2. Install Python 3.10 or newer from https://www.python.org/downloads/windows/ if you do not already have it. Use the official installer/installation manager. Open a new terminal after installation if `py` is not recognised.
3. Double-click `Start-Jarvis.bat`. Keep that terminal window open.
4. A browser opens at `http://127.0.0.1:8765`. Copy the access code from the terminal into the sign-in field.
5. Start with Today, then Money tracker → Add an account. No AI installation is needed for these tools.
6. Close Jarvis using Ctrl+C in the terminal. Closing the browser does not stop the server.

If the launcher cannot find Python, run `python server.py` from a terminal in the extracted folder. If port 8765 is occupied, run `py -3 server.py --port 8766`.

The app uses only Python's standard library. There are no npm packages or paid APIs to install. Internet is required to download Python and optional models, and for external reference links or browser speech services.

## What works now

- Persistent local SQLite records, session access code, same-origin write checks, and loopback-only serving.
- Tasks with dates and completion. Overdue items remain visible in Today; original due dates are preserved.
- Customer notes, follow-up dates and an editable-by-copy introduction template. No automated market research or sending.
- A quotation contribution calculator: selling price minus commission, product cost, freight and packing. Enter all values in the same currency. It is not a final accounting profit figure.
- LKR bank/wallet accounts, opening balances, money in/out and transfers between your accounts.
- Separate personal/business/loan-principal movement labels.
- Outstanding loans lent/borrowed, partial repayments and overpayment prevention. These do not automatically modify bank balances.
- Review-and-confirm statement CSV imports. Exact repeat imports blocked; check overlapping exports manually.
- TXT note import, source labels and optional selection of one note for a local AI question.
- Eight-question, twelve-minute POF calculation practice, tutor mode and answer explanations. Session results and question details persist.
- Six-question interview rehearsal, browser text-to-speech and optional browser dictation. Transcripts save at completion; no audio file is recorded by this app.
- Optional Ollama chat connection to a model running on your PC. No account/ledger data is sent automatically.
- JSON export and a copyable database folder for backups.

## What remains to build

This starter does not yet provide secure iPhone access, offline iPhone caching, cross-device sync, a native mobile app, push reminders, full ATPL coverage, adaptive AI interviews, validated AI-generated question banks, PDF extraction, Oxford application control, bank feeds, Trade Map access, social publishing, Gmail, WhatsApp, multicurrency accounting, automatic categorisation or statutory accounting reports.

The CBT varies numeric inputs; it does not yet vary across the entire ATPL syllabus. Its practice timing and marking are chosen for this starter and are NOT official CAASL or airline examination rules. The questions are original practice, not actual released questions. Reference: FAA Airplane Flying Handbook, Chapter 5 (load factor/stall relationships): https://www.faa.gov/sites/faa.gov/files/regulations_policies/handbooks_manuals/aviation/airplane_handbook/06_afh_ch5.pdf

Recorded training details are user-reported, not a flight logbook. The 250-hour target does not establish airline eligibility. Use your instructor, syllabus and approved aircraft documents to resolve technical uncertainty.

## Optional local AI

1. Install Ollama from https://ollama.com/download/windows and start it.
2. In a terminal, run `ollama pull gemma3:1b` to download a small initial model. Reference: https://ollama.com/library/gemma3
3. In Jarvis, open Settings → Find installed models → select the model → Use selected model.
4. Open Ask Jarvis. Enter a question; optionally include a saved source note.

This small model is only a hardware trial for your 8 GB PC. Its performance and answer quality have NOT been tested on your hardware. It is not a reliable sole authority for aviation or accounting. The app's chat context is one request at a time; it has no automatic long-term conversation memory. It cannot act on your behalf. Large documents are deliberately limited. A response times out after two minutes. Other screens remain usable while the server waits, but returning to a chat screen does not recover an in-flight answer.

## Bank history from January 2026

Use the closing balance on 31 December 2025 as the opening balance dated 1 January 2026, then import subsequent transactions. If a statement starts later, use the known balance immediately before that statement and do not imply earlier history is complete.

For wallets with missing history, enter a known balance and date; only enter transactions after that point. Do not invent transactions to force a match.

CSV format (UTF-8):

```csv
Transaction Date,Description,Currency,Debit,Credit,Running Balance
2026-01-02,Groceries,LKR,1500,,8500
2026-01-03,Money received,LKR,,2500,11000
```

This example requires a LKR 10,000 opening balance. Debit means money out; Credit means money in. Leave the unused side blank, zero or a dash. Each row must contain exactly one positive movement. Exclude opening/closing balance summary rows.

Select YYYY-MM-DD, DD/MM/YYYY or MM/DD/YYYY and oldest-first or newest-first in the import form. Same-day entries must retain the bank's transaction sequence. LKR only is supported; other currencies are rejected without conversion. Thousands separators are allowed inside quoted CSV cells (for example "1,500.00").

Every Running Balance is checked against the account's existing ledger balance, then the preceding row. A discrepancy blocks the entire import; correct opening balances, duplicate/missing entries or row order before retrying. The preview shows all rows, starting balance and ending balance. Saving revalidates against the current ledger. Repeated six-column imports are detected using account, date, description, movement and running balance. Older three-column imports are not fingerprint-compatible, but balance reconciliation provides an additional check.

Import January first, then subsequent statements. Import complete statements, including loan and transfer movements, as uncategorised bank entries. Do not then add the same movement manually. Debt records are separate. Purpose classification and transfer linking after import remain a later feature; balances work but imported entries are not yet an income/expense report.

Loan ledger entries are independent from bank entries. For a loan already outstanding, enter its outstanding balance at the chosen start date; repayments after that date reduce it. A repayment in the debt ledger does not add another bank movement, preventing accidental duplication with statements.

Financial records are append-only. To correct a movement, record an opposite movement with purpose Correction and a descriptive reference, then the correct entry. Debt-entry correction and linked bank/debt reconciliation need a later implementation; double-check debt details before saving.

## Privacy, access and backups

The server intentionally accepts only this PC's localhost addresses. An iPhone cannot use this release remotely yet. Do not change it to listen on all interfaces or forward router ports to expose it. A secure remote-access layer is the next deployment step.

The generated access code changes on restart and is held in an HttpOnly, SameSite cookie. There is no permanent user password. This is local access protection, not an encrypted vault or hardened multiuser hosting product. Anyone with access to your Windows files can read the database. Keep your Windows account and disk protected.

Core records live in `data/jarvis.sqlite3`. To back up or restore: close Jarvis, copy the complete `data` folder to/from a private backup location, then restart. The JSON export is readable for review and migration; a JSON restore interface is not included. No statements, account numbers or actual balances have been preloaded in this package.

Browser dictation depends on browser support and may use a vendor's online speech service. Typed answers always remain available. The app itself does not retain audio. Microphone use on an iPhone and realistic voice latency are not tested.

## Validation

Run `py -3 -m unittest test_core -v` to test decimal validation, transfer amounts, loan overpayments, duplicate imports, date boundaries, atomic rollback, authentication and origin protection. Tests use a temporary database.

The delivered version passed these five automated tests, JavaScript syntax checks, all eight screen-render functions in a simulated DOM, and 1,000 generated-question consistency checks. Live Windows, iPhone, browser layout, microphone and local-model performance tests are still needed. No remote service credentials are embedded.

## Next milestone

Install and open this local starter first. Then validate it with a small redacted statement sample and one permitted Oxford question PDF. After that, prioritise secure iPhone access and a stronger, source-grounded aviation tutor. Do not treat the starter as the completed Jarvis system.

## Update: six-column bank statements

Close Jarvis and back up your existing `data` folder. Extract the updated ZIP into a temporary folder, then copy its program files into your existing Jarvis folder. Keep your existing `data` folder unchanged. Restart and refresh the browser. This update does not include or overwrite a data folder.

Validated with debit/credit, quoted commas, newest-first rows, day-first dates, duplicates, non-LKR rejection, invalid dates, continuation balances and mismatches. Run `py -3 -m unittest test_core test_statements -v`.

## Recurring bank export support

Upload your original bank CSV without editing its columns or footer. Automatic format selection uses DD/MM/YYYY for this bank's slash dates and detects newest-first order. Blank extra columns and the Page footer are ignored. For a single-day export select the row order explicitly.

First import: add an account, select it under Import CSV, tick **Use statement opening balance for an empty account**, then preview. The opening balance inferred from the oldest row is shown for confirmation and only applied when you confirm. It is a balance immediately before the first included transaction, not proof that earlier history is complete. The update is recorded in the audit history.

Later uploads: select the same account and upload the latest export. Exact previously imported statement rows are skipped. Only new rows after the recorded history are added, with running balance checks. An unchanged file reports Already up to date. Interleaved new historical rows, unexplained gaps, or manually entered duplicates still require reconciliation rather than silent insertion. Never add the same bank transaction manually after importing.

This supersedes the earlier instruction to remove overlapping statement rows. Your bank CSV is not bundled with the software or preloaded into a database.
