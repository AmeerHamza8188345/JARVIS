"""Six-column statement parsing and exact-cent reconciliation."""
import csv, datetime, hashlib, io, re
from decimal import Decimal
HEADERS = ['transaction date','description','currency','debit','credit','running balance']
def cents(value, blank=False):
    s=value.strip()
    if blank and s in ('','-'): return 0
    if not re.fullmatch(r'-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,2})?',s):
        raise ValueError('Invalid money value: '+s)
    n=int(Decimal(s.replace(',',''))*100)
    if abs(n)>100000000000000: raise ValueError('Amount exceeds supported limit.')
    return n

def preview(body, accounts, transactions):
    account=next((a for a in accounts if a['id']==body.get('account')),None)
    if not account: raise ValueError('Choose an account.')
    text=body.get('csv','')
    if not isinstance(text,str) or len(text)>1000000: raise ValueError('Use a CSV under 1 MB.')
    reader=csv.reader(io.StringIO(text.lstrip('\ufeff')),strict=True)
    try: rows=list(reader)
    except csv.Error as e: raise ValueError('Invalid CSV: '+str(e))
    rows=[r for r in rows if any(x.strip() for x in r)]
    # Bank export appends empty columns and a printed page footer.
    rows=[r[:6] if len(r)>6 and (not any(x.strip() for x in r[6:]) or (not any(x.strip() for x in r[:6]) and re.fullmatch(r'Page\s+\d+\s+of\s+\d+', ' '.join(x.strip() for x in r[6:] if x.strip()),re.I))) else r for r in rows]
    rows=[r for r in rows if any(x.strip() for x in r)]
    if not rows or [x.strip().lower() for x in rows.pop(0)]!=HEADERS:
        raise ValueError('Required columns: Transaction Date, Description, Currency, Debit, Credit, Running Balance.')
    if not rows or len(rows)>1000: raise ValueError('Include 1–1,000 transaction rows.')
    date_format=body.get('date_format','auto')
    if date_format=='auto': date_format='iso' if '-' in rows[0][0] else 'dmy'
    fmt={'dmy':'%d/%m/%Y','mdy':'%m/%d/%Y','iso':'%Y-%m-%d'}.get(date_format)
    if not fmt: raise ValueError('Choose a supported date format.')
    order=body.get('order','auto')
    if order=='auto':
        try: order='newest' if datetime.datetime.strptime(rows[0][0].strip(),fmt)>datetime.datetime.strptime(rows[-1][0].strip(),fmt) else 'oldest'
        except ValueError: raise ValueError('Invalid statement date.')
        if len(rows)>1 and rows[0][0].strip()==rows[-1][0].strip(): raise ValueError('For a single-day export, choose oldest-first or newest-first explicitly.')
    if order not in ('oldest','newest'): raise ValueError('Choose statement order.')
    numbered=list(enumerate(rows,2))
    if order=='newest': numbered.reverse()
    parsed=[]
    existing={t.get('import_key') for t in transactions if t.get('import_key')}
    seen=set()
    for line,r in numbered:
        try:
            if len(r)!=6: raise ValueError('Expected six columns.')
            day=datetime.datetime.strptime(r[0].strip(),fmt).date().isoformat()
            if r[2].strip().upper()!='LKR': raise ValueError('This version accepts LKR only; no automatic currency conversion.')
            debit,credit,balance=cents(r[3],True),cents(r[4],True),cents(r[5])
            if debit<0 or credit<0 or (debit>0)==(credit>0): raise ValueError('Enter one positive Debit OR Credit; leave the other blank or zero. Exclude opening/closing summary rows.')
            if day<account['date'] and not body.get('use_statement_opening'): raise ValueError('Transaction predates the account opening date.')
            movement=credit-debit
            key=hashlib.sha256(f"{account['id']}|{day}|{r[1].strip()}|{movement}|{balance}".encode()).hexdigest()
            if key in seen: raise ValueError('Repeated identical transaction inside this file; review it before importing.')
            seen.add(key)
            parsed.append({'account':account['id'],'date':day,'title':r[1].strip(),'currency':'LKR','amount':format(Decimal(abs(movement))/100,'.2f'),'direction':'in' if movement>0 else 'out','purpose':'Uncategorised','import_key':key,'statement_balance_cents':balance,'line':line,'movement':movement})
        except (ValueError,OverflowError) as e: raise ValueError(f'CSV row {line}: {e}')
    relevant=[t for t in transactions if t.get('account')==account['id'] or (t.get('to')==account['id'] and t.get('direction')=='transfer')]
    # Reconcile the complete statement independently, including previously imported rows.
    inferred=parsed[0]['statement_balance_cents']-parsed[0]['movement']
    expected=inferred
    previous=parsed[0]['date']
    for row in parsed:
        if row['date']<previous: raise ValueError('Dates are not chronological. Check statement order.')
        previous=row['date']; expected+=row['movement']
        if expected!=row['statement_balance_cents']:
            raise ValueError(f"CSV row {row['line']}: running balance does not match the preceding transaction. Nothing imported.")
    opening_update=None
    if body.get('use_statement_opening') and not relevant:
        opening_update={'opening_cents':inferred,'date':parsed[0]['date']}
    ledger=opening_update['opening_cents'] if opening_update else account['opening_cents']
    for t in relevant:
        if t.get('account')==account['id']: ledger+=t['cents'] if t['direction']=='in' else -t['cents']
        if t.get('to')==account['id'] and t['direction']=='transfer': ledger+=t['cents']
    skipped=0; fresh=[]; started=False
    for row in parsed:
        if row['import_key'] in existing:
            if started: raise ValueError('Existing and new rows are interleaved. Historical backfill needs reconciliation before import.')
            skipped+=1
        else:
            started=True;fresh.append(row)
    latest=max([account['date']]+[t['date'] for t in relevant])
    if fresh and relevant and fresh[0]['date']<latest:
        raise ValueError('New rows predate existing ledger entries. Import history chronologically.')
    start=ledger
    for row in fresh:
        if row['date']<(opening_update or account)['date']: raise ValueError('Transaction predates account opening date.')
        ledger+=row['movement']
        if ledger!=row['statement_balance_cents']:
            raise ValueError(f"CSV row {row['line']}: ledger balance differs from the statement. Check opening balance or manually entered duplicates. On a new, empty account select Use statement opening balance. Nothing imported.")
    return {'rows':fresh,'opening_cents':start,'closing_cents':ledger,'count':len(fresh),'skipped':skipped,'statement_count':len(parsed),'opening_update':opening_update,'statement_opening_cents':inferred,'statement_closing_cents':parsed[-1]['statement_balance_cents'],'date_format':date_format,'order':order}
